# Verida + PyTorch Differential Privacy Experiment

# Dataset: 
https://huggingface.co/datasets/Ezi/medical_and_legislators_synthetic

# Objective:

#

# Notes:
1. Appended with synthetically generated VDA DiD