

if __name__ == "__main__":
    PROJECT = "PII_Customer_Personality_Analysis"
    VERSION = 0.1
