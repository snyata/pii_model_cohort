# Using Gretel AI to Redact PII 
### Applying Gretel.ai's dfferential AI to the equivalent dataset


